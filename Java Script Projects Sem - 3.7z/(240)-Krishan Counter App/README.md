<!DOCTYPE html>
<html>
<head>
  <title>Counter App</title>
</head>
<body>

  <h1>Counter App</h1>

  <!-- Display number -->
  <h2 id="value">0</h2>

  <!-- Buttons -->
  <button id="decrease">Decrease</button>
  <button id="reset">Reset</button>
  <button id="increase">Increase</button>

  <script>
    // Start with value 0
    let count = 0;

    // Get HTML elements
    let value = document.getElementById("value");
    let btnDecrease = document.getElementById("decrease");
    let btnReset = document.getElementById("reset");
    let btnIncrease = document.getElementById("increase");

    // Increase button
    btnIncrease.onclick = function () {
      count = count + 1;         // add 1
      value.textContent = count; // show number on screen
    }

    // Decrease button
    btnDecrease.onclick = function () {
      count = count - 1;         // minus 1
      value.textContent = count; // update screen
    }

    // Reset button
    btnReset.onclick = function () {
      count = 0;                 // back to zero
      value.textContent = count; // show 0
    }
  </script>

</body>
</html>
